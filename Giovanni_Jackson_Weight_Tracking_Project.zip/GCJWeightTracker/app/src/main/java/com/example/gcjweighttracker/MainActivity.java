package com.example.gcjweighttracker;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int SMS_REQUEST = 100;

    // Project Two uses temporary sample data to demonstrate the interface.
    private final ArrayList<WeightEntry> entries = new ArrayList<>();
    private final Calendar selectedDate = Calendar.getInstance();

    private double goalWeight = 180.0;
    private boolean smsOptIn = false;
    private String phoneNumber = "";
    private String currentScreen = "login";

    private static class WeightEntry {
        long date;
        double weight;

        WeightEntry(long date, double weight) {
            this.date = date;
            this.weight = weight;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Sample rows demonstrate the grid before database work is added.
        Calendar sampleDate = Calendar.getInstance();
        sampleDate.add(Calendar.DAY_OF_MONTH, -1);
        entries.add(new WeightEntry(sampleDate.getTimeInMillis(), 192.0));

        sampleDate.add(Calendar.DAY_OF_MONTH, -1);
        entries.add(new WeightEntry(sampleDate.getTimeInMillis(), 193.5));

        showLogin();
    }

    // Apply system-bar spacing to each screen.
    private void openScreen(int layout, String screenName) {
        currentScreen = screenName;
        setContentView(layout);

        View root = findViewById(R.id.screenRoot);

        root.setOnApplyWindowInsetsListener((view, insets) -> {
            view.setPadding(
                    insets.getSystemWindowInsetLeft(),
                    insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(),
                    insets.getSystemWindowInsetBottom()
            );
            return insets;
        });

        root.requestApplyInsets();
    }

    private void showLogin() {
        openScreen(R.layout.activity_main, "login");

        EditText username = findViewById(R.id.usernameInput);
        EditText password = findViewById(R.id.passwordInput);

        View.OnClickListener openPreview = view -> {
            if (username.getText().toString().trim().isEmpty()) {
                username.setError(getString(R.string.required_login));
                username.requestFocus();
                return;
            }

            if (password.getText().toString().isEmpty()) {
                password.setError(getString(R.string.required_login));
                password.requestFocus();
                return;
            }

            // Navigation only: authentication is added in Project Three.
            Toast.makeText(
                    this,
                    R.string.preview_login,
                    Toast.LENGTH_LONG
            ).show();

            password.setText("");
            showWeights();
        };

        findViewById(R.id.loginButton).setOnClickListener(openPreview);
        findViewById(R.id.createAccountButton)
                .setOnClickListener(openPreview);
    }

    private void showWeights() {
        openScreen(R.layout.activity_weights, "weights");

        EditText goalInput = findViewById(R.id.goalInput);
        EditText weightInput = findViewById(R.id.weightInput);
        Button dateButton = findViewById(R.id.dateButton);

        goalInput.setText(formatWeight(goalWeight));
        dateButton.setText(formatDate(selectedDate.getTimeInMillis()));

        dateButton.setOnClickListener(view -> {
            DatePickerDialog picker = new DatePickerDialog(
                    this,
                    (datePicker, year, month, day) -> {
                        selectedDate.set(year, month, day);
                        dateButton.setText(
                                formatDate(selectedDate.getTimeInMillis())
                        );
                    },
                    selectedDate.get(Calendar.YEAR),
                    selectedDate.get(Calendar.MONTH),
                    selectedDate.get(Calendar.DAY_OF_MONTH)
            );

            picker.getDatePicker().setMaxDate(System.currentTimeMillis());
            picker.show();
        });

        findViewById(R.id.saveGoalButton).setOnClickListener(view -> {
            double value = readWeight(goalInput);

            if (value <= 0) {
                return;
            }

            goalWeight = value;
            updateSummary();
        });

        findViewById(R.id.addWeightButton).setOnClickListener(view -> {
            double value = readWeight(weightInput);

            if (value <= 0) {
                return;
            }

            entries.add(new WeightEntry(
                    selectedDate.getTimeInMillis(),
                    value
            ));

            entries.sort((first, second) ->
                    Long.compare(second.date, first.date));

            weightInput.setText("");
            renderRows();
            updateSummary();
        });

        findViewById(R.id.smsButton)
                .setOnClickListener(view -> showSms());

        findViewById(R.id.logoutButton)
                .setOnClickListener(view -> showLogin());

        renderRows();
        updateSummary();
    }

    private double readWeight(EditText input) {
        try {
            String text = input.getText().toString().trim();
            double value = Double.parseDouble(text.replace(',', '.'));

            if (value > 0 && !Double.isInfinite(value)
                    && !Double.isNaN(value)) {
                return value;
            }
        } catch (NumberFormatException ignored) {
            // Display an inline error below.
        }

        input.setError(getString(R.string.weight_invalid));
        input.requestFocus();
        return -1;
    }

    private void updateSummary() {
        TextView goalSummary = findViewById(R.id.goalSummary);
        TextView progressSummary = findViewById(R.id.progressSummary);

        goalSummary.setText(getString(
                R.string.goal_summary,
                formatWeight(goalWeight)
        ));

        if (entries.isEmpty()) {
            progressSummary.setText(R.string.no_entries);
            return;
        }

        double latest = entries.get(0).weight;

        progressSummary.setText(getString(
                R.string.progress_summary,
                formatWeight(latest),
                formatWeight(Math.abs(latest - goalWeight))
        ));
    }

    // Display a date, weight, and delete control in every grid row.
    private void renderRows() {
        TableLayout table = findViewById(R.id.weightTable);

        if (table.getChildCount() > 1) {
            table.removeViews(1, table.getChildCount() - 1);
        }

        for (WeightEntry entry : entries) {
            TableRow row = new TableRow(this);
            row.setBackgroundColor(Color.WHITE);

            TextView dateCell = createCell(formatDate(entry.date));
            TextView weightCell = createCell(formatWeight(entry.weight));

            Button deleteButton = new Button(this);
            deleteButton.setText(R.string.delete);
            deleteButton.setTextSize(14);
            deleteButton.setAllCaps(false);
            deleteButton.setMinWidth(0);
            deleteButton.setMinimumWidth(0);
            deleteButton.setMinHeight(dp(48));
            deleteButton.setTextColor(Color.parseColor("#9C2929"));

            deleteButton.setContentDescription(getString(
                    R.string.delete_description,
                    formatDate(entry.date)
            ));

            deleteButton.setLayoutParams(new TableRow.LayoutParams(
                    0,
                    TableRow.LayoutParams.WRAP_CONTENT,
                    1
            ));

            deleteButton.setOnClickListener(view ->
                    new AlertDialog.Builder(this)
                            .setTitle(R.string.delete_title)
                            .setMessage(getString(
                                    R.string.delete_message,
                                    formatDate(entry.date)
                            ))
                            .setNegativeButton(R.string.cancel, null)
                            .setPositiveButton(
                                    R.string.delete,
                                    (dialog, which) -> {
                                        entries.remove(entry);
                                        renderRows();
                                        updateSummary();
                                    }
                            )
                            .show()
            );

            row.addView(dateCell);
            row.addView(weightCell);
            row.addView(deleteButton);
            table.addView(row);
        }
    }

    private TextView createCell(String text) {
        TextView cell = new TextView(this);
        cell.setText(text);
        cell.setTextSize(16);
        cell.setTextColor(Color.parseColor("#173D36"));
        cell.setPadding(dp(8), dp(12), dp(8), dp(12));

        cell.setLayoutParams(new TableRow.LayoutParams(
                0,
                TableRow.LayoutParams.WRAP_CONTENT,
                1
        ));

        return cell;
    }

    private void showSms() {
        openScreen(R.layout.activity_sms, "sms");

        EditText phoneInput = findViewById(R.id.phoneInput);
        phoneInput.setText(phoneNumber);

        findViewById(R.id.allowSmsButton).setOnClickListener(view -> {
            phoneNumber = phoneInput.getText().toString().trim();

            if (!supportsSms()) {
                updateSmsStatus();
                return;
            }

            if (checkSelfPermission(Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                smsOptIn = true;
                updateSmsStatus();
            } else {
                requestPermissions(
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_REQUEST
                );
            }
        });

        findViewById(R.id.skipSmsButton).setOnClickListener(view -> {
            phoneNumber = phoneInput.getText().toString().trim();

            // Declining SMS does not block the weight-tracking screen.
            smsOptIn = false;
            showWeights();
        });

        findViewById(R.id.backButton).setOnClickListener(view -> {
            phoneNumber = phoneInput.getText().toString().trim();
            showWeights();
        });

        updateSmsStatus();
    }

    private boolean supportsSms() {
        return getPackageManager().hasSystemFeature(
                PackageManager.FEATURE_TELEPHONY
        );
    }

    private void updateSmsStatus() {
        if (!currentScreen.equals("sms")) {
            return;
        }

        TextView status = findViewById(R.id.smsStatus);
        Button allowButton = findViewById(R.id.allowSmsButton);

        boolean supported = supportsSms();
        allowButton.setEnabled(supported);

        if (!supported) {
            status.setText(R.string.sms_unavailable);
        } else if (smsOptIn
                && checkSelfPermission(Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            status.setText(R.string.sms_allowed);
        } else {
            status.setText(R.string.sms_off);
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode, permissions, grantResults);

        if (requestCode == SMS_REQUEST) {
            smsOptIn = grantResults.length > 0
                    && grantResults[0]
                    == PackageManager.PERMISSION_GRANTED;

            updateSmsStatus();

            if (!smsOptIn && currentScreen.equals("sms")) {
                TextView status = findViewById(R.id.smsStatus);
                status.setText(R.string.sms_denied);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateSmsStatus();
    }

    @Override
    public void onBackPressed() {
        if (currentScreen.equals("sms")) {
            EditText phoneInput = findViewById(R.id.phoneInput);
            phoneNumber = phoneInput.getText().toString().trim();
            showWeights();
        } else if (currentScreen.equals("weights")) {
            showLogin();
        } else {
            super.onBackPressed();
        }
    }

    private String formatDate(long date) {
        return new SimpleDateFormat(
                "MM/dd/yyyy",
                Locale.US
        ).format(new Date(date));
    }

    private String formatWeight(double weight) {
        return String.format(Locale.US, "%.1f", weight);
    }

    private int dp(int value) {
        return Math.round(
                value * getResources().getDisplayMetrics().density
        );
    }
}